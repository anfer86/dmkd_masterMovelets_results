package br.ufsc.trajectoryclassification.model.bo.featureExtraction;

import java.util.List;

import br.ufsc.trajectoryclassification.model.vo.ITrajectory;

public interface IPointFeature {

	public void fillPoints(ITrajectory trajectory);
	
}
