package br.ufsc.trajectoryclassification.model.bo.featureExtraction;

import br.ufsc.trajectoryclassification.model.vo.ITrajectory;

public interface ITrajectoryFeature {

	public void fillTrajectory(ITrajectory trajectory);

}
